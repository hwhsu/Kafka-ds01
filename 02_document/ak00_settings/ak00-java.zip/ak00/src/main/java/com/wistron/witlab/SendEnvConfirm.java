/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.wistron.witlab;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wistron.witlab.model.StudentEnv;
import org.apache.kafka.clients.producer.KafkaProducer;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.util.Properties;

/**
 * 用來驗證學員的個人環境的完備與上課用的開發環境。使用前請先修改：
 *  * (1) KAFKA_BROKER_URL
 *  * (2) STUDENT_ID
 */
public class SendEnvConfirm {

    private static String KAFKA_BROKER_URL = "streamgeeks.org:9092"; // 設定要連接的Kafka群

    private static String WORKSHOP_ID = "ds01";                  // 修改成你/妳課程的工作坊編號
    private static String STUDENT_ID = "dsxxxx";                 // 修改成你/妳的學員編號

    public static void main(String[] args) {
        // 步驟1. 設定要連線到Kafka集群的相關設定
        Properties props = new Properties();
        props.put("bootstrap.servers", KAFKA_BROKER_URL); // Kafka集群在那裡?
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer"); // 指定msgKey的序列化器
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer"); // 指定msgValue的序列化器
        // 用來序列化物件to Json
        ObjectMapper om = new ObjectMapper();
        // 步驟2. 產生一個Kafka的Producer的實例
        Producer<String, String> producer = new KafkaProducer<>(props);
        // 步驟3. 指定想要發佈訊息的topic名稱
        String topicName = "ak00.ws"+WORKSHOP_ID+".env";
        try {
            // 檢查學員編號
            if(validateStudentID(STUDENT_ID)){ // 有效的學員編號
                System.out.println("Start to check environment ....");
                // 取得學員的JDK環境與O.S
                StudentEnv studentEnv = buildStudentEnv(STUDENT_ID);

                 boolean result = validateStudentEnv(studentEnv);
                System.out.println(om.writeValueAsString(studentEnv));

                // 發佈學員JDK與OS訊息到Kakfa以便助教幫助學員解決環境問題
                //    - 參數#1: topicName
                //    - 參數#2: msgKey
                //    - 參數#3: msgValue
                producer.send(new ProducerRecord<>(topicName, STUDENT_ID, om.writeValueAsString(studentEnv))).get();
                System.out.println("The confirmation is send out successfully!");
            }
        } catch (Exception e) {
            // 錯誤處理
            e.printStackTrace();
            System.err.println("Encounter issue to send out confirmation!");
        }
        // 步驟5. 關掉Producer實例的連線
        producer.close();
    }

    // 檢查學員編號是否為有效的format
    private static boolean validateStudentID(String studentID) {
        if (studentID==null || studentID.isEmpty()){
            System.err.println("Error: Invalid student ID!");
            return false;
        }
        return true;
    }

    // 檢查學員的JDK環境與O.S
    private static StudentEnv buildStudentEnv(String studentID) {
        String studentId = studentID;
        String osName= System.getProperty("os.name"); // Windows 10
        String osVersion = System.getProperty("os.version");
        String javaSpecVersion= System.getProperty("java.specification.version"); // 1.8

        StudentEnv studentEnv = new StudentEnv(studentID, osName, osVersion);
        studentEnv.setEnvAttr("langName", "Java");
        studentEnv.setEnvAttr("langVersion", javaSpecVersion);
        return studentEnv;
    }

    private static boolean validateStudentEnv(StudentEnv env) {
        System.out.println();
        boolean result = true;

        // 檢查JDK版本是否大於等於 1.8
        try{
            float ver = Float.parseFloat(env.getEnvAttr("langVersion"));
            if(ver < 1.8f){
                System.out.println(String.format("Your JDK spec version is {}, the minimum version is {}", env.getEnvAttr("langVersion"), "1.8"));
                result = false;
            }
        }catch(Exception e){
            result = false;
        }

        if (result) {
            System.out.println("Congratulations, your Environment is ready!");
        } else {
            System.out.println("Your Java Environment is \"NOT\" fulfilled class requirement.");
            System.out.println("Please contact Teaching Assistent (TA) to resolve.");
            System.out.println();
            System.out.println("** The minimum requiremets: Java ver >= 1.8 **");
        }

        return result;
    }
}
