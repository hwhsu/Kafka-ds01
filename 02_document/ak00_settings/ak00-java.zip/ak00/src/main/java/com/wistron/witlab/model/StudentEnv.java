/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.wistron.witlab.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * 用來幫助學員檢查個人開發環境是否可以符合上課的要求
 */
public class StudentEnv {
    private String studentId;
    private String osName;
    private String osVersion;
    private Map<String, String> envAttrs = new HashMap<>();

    public StudentEnv() {
    }

    public StudentEnv(String studentId, String osName, String osVersion) {
        this.studentId = studentId;
        this.osName = osName;
        this.osVersion = osVersion;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getOsName() {
        return osName;
    }

    public void setOsName(String osName) {
        this.osName = osName;
    }

    public String getOsVersion() {
        return osVersion;
    }

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    public Map<String, String> getEnvAttrs() {
        return envAttrs;
    }

    public void setEnvAttr(String attrName, String attrValue) {
        envAttrs.put(attrName, attrValue);
    }

    public String getEnvAttr(String attrName) {
        return envAttrs.get(attrName);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StudentEnv that = (StudentEnv) o;
        return Objects.equals(studentId, that.studentId) &&
                Objects.equals(osName, that.osName) &&
                Objects.equals(osVersion, that.osVersion) &&
                Objects.equals(envAttrs, that.envAttrs);
    }

    @Override
    public int hashCode() {

        return Objects.hash(studentId, osName, osVersion, envAttrs);
    }

    @Override
    public String toString() {
        return "StudentEnv{" +
                "studentId='" + studentId + '\'' +
                ", osName='" + osName + '\'' +
                ", osVersion='" + osVersion + '\'' +
                ", envAttrs=" + envAttrs +
                '}';
    }
}
